import static java.lang.Math.pow;
import java.util.*;

class Powmod{
    long powmod(long a,long b,long c)
    {
            if(b==1)
                return a;
            else 
                return (long) (pow(a,b)%c);            
    }
}

public class Df {
    public static void main(String[] args) {
        
        Powmod pm =new Powmod();
        Scanner sc = new Scanner(System.in);
        long p,g,c,d,x,y,ka,kb;
        
        System.out.println("Enter the 2 public numbers: ");
        p = sc.nextLong();
        g= sc.nextLong();
         
        System.out.println("ENter the sender side private key: ");
        c = sc.nextLong();
        
        System.out.println("ENter the receiver side private key: ");
        d = sc.nextLong();
        
        //generation of keys
        x = pm.powmod(g,c,p);
        y = pm.powmod(g,d,p);
       
        //generation of keys after exchange
        ka = pm.powmod(y,c,p);
        kb = pm.powmod(x,d,p);
        System.out.println("Secret key for sender: "+ka);
        System.out.println("Secret key for receiver: "+kb); 
    }
}

// ip 23 and 27
//private key 4 and 3 n