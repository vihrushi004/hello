import java.util.Scanner;

class Cipher{
    char ar[];
    int key;
    String ciph_text, plain_text;
    Scanner sc=new Scanner(System.in);
    
    String encode()
    {
         String d;
          System.out.println("Enter Plain text ");
        plain_text=sc.nextLine();
         d=plain_text.toUpperCase();
        System.out.println("Enter key value");
        key=sc.nextInt();
     ar=d.toCharArray();
     System.out.println("Encrypted data");
        for (int i = 0; i < ar.length; i++)
        {
                 ar[i]=(char) (((((ar[i]-65)+key)%26))+65);
        }
                 ciph_text=new String(ar);
                System.out.println(ciph_text);
           
        decode();
       return null;
              
    }
    
     String decode(){
        
        for (int i = 0; i < ar.length; i++) {
             ar[i]=(char) (((((ar[i]-65)-key)%26))+65);
           
        }
        System.out.println("plainText After decoding");
            plain_text=new String(ar);
                System.out.println(plain_text);
   
       return null;
              
    }
    
   
}
public class AdditiveCipher{

    public static void main(String[] args) {
        
        Cipher  ob =new Cipher();
        ob.encode();
       
    }
    
}