// NOte working input 
// p=3 q=11
 // e=7


import java.util.Scanner;
class calculation{
     int p,q,e,d,n ;
    int fn;
    int pve[]=new int[150];
     
    String plaintext,ciphtext;
    char ar[];
    Scanner sc=new Scanner(System.in);
    
    boolean isprime(int n){
        boolean val=true;
        for (int i = 2; i <n; i++) {
            if(n%i==0){
                val=false;
                break;
            }
        }
        return val;
    }
     int inverse(int temp){
       int r1,r2,t1,t2,q,r,t,val=0;
       r1=60;
       r2=temp;
       t1=0;
       t2=1;
       
         
      while(r2>0){
         q=r1/r2;
         r=r1-(q*r2);
         r1=r2;
         r2=r;
         t = t1-(q*t2);
         t1=t2;
         t2=t;
      }
     
       if(r1==1){
           
            if(t1<0){
             val=t1+60;
             }
              else{
                  val=t1;
              }
       }
      return val;
    
 }  
     int gcd(int n1,int n2){
         while(n1!=n2){
             if(n1>n2){
                 n1-=n2;
             }
             else{
                 n2-=n1;
             }
         }
       return n1;
     }
     void cale(){
         int j=0;
         System.out.println("Possible values of e ");
         for (int i = 1; i < fn; i++) {
             if(gcd(i,fn)==1)
               {
              pve[j]=i;
                   System.out.print(pve[j]+"\t");
                }
             j++;
         }
         System.out.println("\n Select any 1 value");
         e=sc.nextInt();
        
         
     }
void incrypt(){
    System.out.println("Enter value of  two prime no");
    p=sc.nextInt();
    q=sc.nextInt();
    if(isprime(p)&& isprime(q)){
        System.out.println("Enter plain text");
        plaintext=sc.next();
        n=p*q;
        fn=(p-1)*(q-1);
        cale();
        System.out.println("value of e"+e);
        d=inverse(e)%fn ;
         plaintext=plaintext.toUpperCase();
         ar=plaintext.toCharArray();
          for (int i = 0; i <ar.length; i++) {
                    //System.out.println((int)ar[i]);
                     ar[i]= (char) ((((Math.pow(ar[i]-65, e)%n) + 65)));
                    //System.out.println((int)ar[i]-65);
                } 
         System.out.println("Cipher text is ");
         ciphtext =new String(ar);
         System.out.println(ciphtext);
    }
            
}
void decrypt(){
   
    System.out.println("After decoding");
            
    for (int i = 0; i <ar.length; i++) {
       // System.out.println(ar[i]-65); 
        ar[i]= (char) ((((Math.pow(ar[i]-65, d)%n) + 65)));
          // System.out.println(ar[i]);
        }
     String pt = new String (ar);
    System.out.println(pt);
}
    
}

public class Rsa {

    public static void main(String[] args) {
       
        calculation ob =new calculation();
        ob.incrypt();
         ob.decrypt();
         
     
    }
}


