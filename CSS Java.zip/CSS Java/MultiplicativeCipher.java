import java.util.Scanner;
class cipher {
    int n,key;
    String plain_text, cipher_text;
    char ar[];
    Scanner sc=new Scanner(System.in);
   int inverse()
{
       int r1,r2,t1,t2,q,r,t,val=0;
       r1=26;
       r2=key;
       t1=0;
       t2=1;
      while(r2>0)
     {
         q=r1/r2;
         r=r1-(q*r2);
         r1=r2;
         r2=r;
         t = t1-(q*t2);
         t1=t2;
         t2=t;
      }
       if(r1==1)
	{
           
            if(t1<0)
	    {
             val=t1+26;
             }
              else
	     {
                  val=t1;
              }
       }
      return val;
    
 }
         
    void  Encode()
{
    
        System.out.println("Enter Plain text ");
        plain_text=sc.nextLine();
        System.out.println("Enter key");
        key=sc.nextInt();
        plain_text=plain_text.toUpperCase();
              ar=plain_text.toCharArray();
        if(key<26)
	{
            if(key%2!=0 || key!=13)
            {
  
                for (int i = 0; i <ar.length; i++) 
		{
               
                     ar[i]= (char) ((((ar[i]-65)*key)%26) + 65);
                     
                } 
                cipher_text=new String(ar);
                 System.out.println("Cipher text is ");
                System.out.println(cipher_text);
            } 
        }
        else 
	{
            System.out.println("Enter Valid key ");
        }
        
    
}
    void decode()
   {
  
         int inv_value=inverse();
        for (int i = 0; i <ar.length; i++) 
	{
            ar[i]=(char) (((((ar[i]-65)*inv_value)%26))+65);
        }
        System.out.println("plainText After decoding");
            plain_text=new String(ar);
                System.out.println(plain_text);
    }
}
public class MultiplicativeCipher {

    
    public static void main(String[] args) 
    {
  
        cipher ob =new  cipher();
        ob.Encode();
        ob.decode();
        
    }
    
}